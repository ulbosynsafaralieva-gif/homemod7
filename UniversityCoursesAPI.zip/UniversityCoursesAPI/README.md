# UniversityCoursesAPI

Web API управления учебными курсами университета (ASP.NET Core, .NET 8).
Basic Authentication + авторизация по ролям (Admin / Teacher / Student) на собственных атрибутах.

## Запуск
```
dotnet restore
dotnet run
```
Приложение: https://localhost:7001 (Swagger: /swagger). Порт можно изменить в `Properties/launchSettings.json`
(тогда обновите переменную `baseUrl` в Postman).

## Тестовые пользователи
| Логин   | Пароль     | Роль    |
|---------|------------|---------|
| admin   | admin123   | Admin   |
| teacher | teacher123 | Teacher |
| student | student123 | Student |

## Права доступа
| Метод  | Маршрут             | Роли                       |
|--------|---------------------|----------------------------|
| GET    | /api/courses        | Admin, Teacher, Student    |
| GET    | /api/courses/{id}   | Admin, Teacher, Student    |
| POST   | /api/courses        | Admin, Teacher             |
| PUT    | /api/courses/{id}   | Admin, Teacher             |
| DELETE | /api/courses/{id}   | Admin                      |
| GET    | /api/courses/info   | Все (анонимно)             |

## Структура
- `Models/` — User, Course, Roles
- `Services/UserService.cs` — проверка логина/пароля; `CourseService.cs` — курсы в памяти
- `Attributes/BasicAuthenticationAttribute.cs` — Basic Authentication (401)
- `Attributes/MyAuthorizeAttribute.cs` — проверка ролей (401 / 403)
- `Controllers/CoursesController.cs`
- `Postman/` — коллекция из 8 сценариев задания 5 (с автотестами кодов ответа)

## Тестирование в Postman
Import → `Postman/UniversityCoursesAPI.postman_collection.json` → Run collection.
Если Postman ругается на сертификат: Settings → отключить «SSL certificate verification» или выполнить `dotnet dev-certs https --trust`.
