using Microsoft.OpenApi.Models;
using UniversityCoursesAPI.Services;

var builder = WebApplication.CreateBuilder(args);

// Тестовые пользователи и курсы хранятся в памяти приложения (допустимо для учебного задания)
builder.Services.AddSingleton<UserService>();
builder.Services.AddSingleton<CourseService>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo { Title = "UniversityCoursesAPI", Version = "v1" });

    // Кнопка Authorize (Basic) в Swagger UI
    options.AddSecurityDefinition("basic", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "basic",
        In = ParameterLocation.Header,
        Description = "Basic Authentication: введите логин и пароль"
    });
    options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "basic" }
            },
            Array.Empty<string>()
        }
    });
});

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.MapControllers();

app.Run();
