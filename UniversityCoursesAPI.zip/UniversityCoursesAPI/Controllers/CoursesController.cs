using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using UniversityCoursesAPI.Attributes;
using UniversityCoursesAPI.Models;
using UniversityCoursesAPI.Services;

namespace UniversityCoursesAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
[BasicAuthentication]                       // аутентификация для всех методов контроллера
public class CoursesController : ControllerBase
{
    private readonly CourseService _courses;

    public CoursesController(CourseService courses)
    {
        _courses = courses;
    }

    // GET /api/courses/info — публичный метод, доступен всем (в т.ч. анонимным)
    [HttpGet("info")]
    [AllowAnonymous]
    public IActionResult Info()
    {
        return Ok(new
        {
            name = "UniversityCoursesAPI",
            description = "Web API для управления учебными курсами университета",
            version = "1.0",
            authentication = "Basic",
            roles = new[] { Roles.Admin, Roles.Teacher, Roles.Student }
        });
    }

    // GET /api/courses — Admin, Teacher, Student
    [HttpGet]
    [MyAuthorize(Roles.Admin, Roles.Teacher, Roles.Student)]
    public ActionResult<IEnumerable<Course>> GetAll()
    {
        return Ok(_courses.GetAll());
    }

    // GET /api/courses/{id} — Admin, Teacher, Student
    [HttpGet("{id:int}")]
    [MyAuthorize(Roles.Admin, Roles.Teacher, Roles.Student)]
    public ActionResult<Course> GetById(int id)
    {
        var course = _courses.GetById(id);
        return course is null ? NotFound(new { message = $"Курс с Id={id} не найден." }) : Ok(course);
    }

    // POST /api/courses — Admin, Teacher
    [HttpPost]
    [MyAuthorize(Roles.Admin, Roles.Teacher)]
    public ActionResult<Course> Create([FromBody] Course course)
    {
        var created = _courses.Add(course);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);   // 201
    }

    // PUT /api/courses/{id} — Admin, Teacher
    [HttpPut("{id:int}")]
    [MyAuthorize(Roles.Admin, Roles.Teacher)]
    public ActionResult<Course> Update(int id, [FromBody] Course course)
    {
        var updated = _courses.Update(id, course);
        return updated is null ? NotFound(new { message = $"Курс с Id={id} не найден." }) : Ok(updated);
    }

    // DELETE /api/courses/{id} — только Admin
    [HttpDelete("{id:int}")]
    [MyAuthorize(Roles.Admin)]
    public IActionResult Delete(int id)
    {
        return _courses.Delete(id)
            ? NoContent()                                                    // 204
            : NotFound(new { message = $"Курс с Id={id} не найден." });
    }
}
