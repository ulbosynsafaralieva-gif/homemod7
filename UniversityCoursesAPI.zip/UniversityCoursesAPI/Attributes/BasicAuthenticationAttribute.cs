using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using UniversityCoursesAPI.Services;

namespace UniversityCoursesAPI.Attributes;

/// <summary>
/// Самостоятельная реализация Basic Authentication.
/// Читает заголовок Authorization, декодирует Base64, проверяет логин/пароль,
/// создаёт ClaimsIdentity + ClaimsPrincipal и сохраняет их в HttpContext.User.
/// При отсутствии или некорректности учётных данных возвращает 401.
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public class BasicAuthenticationAttribute : Attribute, IAsyncAuthorizationFilter
{
    public Task OnAuthorizationAsync(AuthorizationFilterContext context)
    {
        // Для методов с [AllowAnonymous] аутентификация не требуется
        if (context.ActionDescriptor.EndpointMetadata.OfType<IAllowAnonymous>().Any())
            return Task.CompletedTask;

        var request = context.HttpContext.Request;

        // 1. Получаем заголовок Authorization
        if (!request.Headers.TryGetValue("Authorization", out var headerValues))
        {
            context.Result = Unauthorized(context, "Отсутствует заголовок Authorization.");
            return Task.CompletedTask;
        }

        var header = headerValues.ToString();
        const string prefix = "Basic ";
        if (!header.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
        {
            context.Result = Unauthorized(context, "Поддерживается только схема Basic.");
            return Task.CompletedTask;
        }

        // 2. Декодируем Base64 -> "login:password"
        string decoded;
        try
        {
            var bytes = Convert.FromBase64String(header[prefix.Length..].Trim());
            decoded = Encoding.UTF8.GetString(bytes);
        }
        catch (FormatException)
        {
            context.Result = Unauthorized(context, "Некорректная строка Base64.");
            return Task.CompletedTask;
        }

        var separator = decoded.IndexOf(':');
        if (separator < 0)
        {
            context.Result = Unauthorized(context, "Ожидается формат login:password.");
            return Task.CompletedTask;
        }

        var username = decoded[..separator];
        var password = decoded[(separator + 1)..];

        // 3. Проверяем логин и пароль
        var userService = context.HttpContext.RequestServices.GetRequiredService<UserService>();
        var user = userService.ValidateCredentials(username, password);
        if (user is null)
        {
            context.Result = Unauthorized(context, "Неверный логин или пароль.");
            return Task.CompletedTask;
        }

        // 4. Создаём ClaimsIdentity и ClaimsPrincipal
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new(ClaimTypes.Name, user.Username),
            new(ClaimTypes.Email, user.Email),
            new(ClaimTypes.Role, user.Role)
        };
        var identity = new ClaimsIdentity(claims, "Basic");   // authenticationType != null => IsAuthenticated = true
        var principal = new ClaimsPrincipal(identity);

        // 5. Сохраняем пользователя в HttpContext.User
        context.HttpContext.User = principal;

        return Task.CompletedTask;
    }

    private static IActionResult Unauthorized(AuthorizationFilterContext context, string message)
    {
        context.HttpContext.Response.Headers["WWW-Authenticate"] = "Basic realm=\"UniversityCoursesAPI\"";
        return new JsonResult(new { status = 401, error = "Unauthorized", message }) { StatusCode = StatusCodes.Status401Unauthorized };
    }
}
