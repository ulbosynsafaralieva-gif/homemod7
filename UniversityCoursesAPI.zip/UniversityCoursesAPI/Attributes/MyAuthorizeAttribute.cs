using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace UniversityCoursesAPI.Attributes;

/// <summary>
/// Пользовательский атрибут авторизации на основе ролей.
/// Пример: [MyAuthorize("Admin", "Teacher")].
/// 401 — пользователь не аутентифицирован; 403 — аутентифицирован, но роль не подходит.
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
public class MyAuthorizeAttribute : Attribute, IAuthorizationFilter
{
    private readonly string[] _roles;

    public MyAuthorizeAttribute(params string[] roles)
    {
        _roles = roles;
    }

    public void OnAuthorization(AuthorizationFilterContext context)
    {
        // [AllowAnonymous] отключает проверку
        if (context.ActionDescriptor.EndpointMetadata.OfType<IAllowAnonymous>().Any())
            return;

        // Если предыдущий фильтр (BasicAuthentication) уже вернул 401 — ничего не делаем
        if (context.Result is not null)
            return;

        var user = context.HttpContext.User;

        // Пользователь не аутентифицирован -> 401
        if (user.Identity is null || !user.Identity.IsAuthenticated)
        {
            context.HttpContext.Response.Headers["WWW-Authenticate"] = "Basic realm=\"UniversityCoursesAPI\"";
            context.Result = new JsonResult(new { status = 401, error = "Unauthorized", message = "Требуется аутентификация." })
            {
                StatusCode = StatusCodes.Status401Unauthorized
            };
            return;
        }

        // Роли не заданы — достаточно быть аутентифицированным
        if (_roles.Length == 0)
            return;

        // Проверка роли -> 403
        if (!_roles.Any(role => user.IsInRole(role)))
        {
            context.Result = new JsonResult(new
            {
                status = 403,
                error = "Forbidden",
                message = $"Недостаточно прав. Требуется одна из ролей: {string.Join(", ", _roles)}."
            })
            {
                StatusCode = StatusCodes.Status403Forbidden
            };
        }
    }
}
