using UniversityCoursesAPI.Models;

namespace UniversityCoursesAPI.Services;

/// <summary>Проверка учётных данных пользователей (хранилище в памяти).</summary>
public class UserService
{
    private readonly List<User> _users = new()
    {
        new User { Id = 1, Username = "admin",   Password = "admin123",   Email = "admin@university.test",   Role = Roles.Admin },
        new User { Id = 2, Username = "teacher", Password = "teacher123", Email = "teacher@university.test", Role = Roles.Teacher },
        new User { Id = 3, Username = "student", Password = "student123", Email = "student@university.test", Role = Roles.Student }
    };

    /// <summary>Возвращает пользователя, если логин и пароль верны, иначе null.</summary>
    public User? ValidateCredentials(string username, string password)
    {
        return _users.FirstOrDefault(u =>
            u.Username.Equals(username, StringComparison.OrdinalIgnoreCase) &&
            u.Password == password);
    }
}
