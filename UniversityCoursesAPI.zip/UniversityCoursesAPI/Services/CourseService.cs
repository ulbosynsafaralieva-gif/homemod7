using UniversityCoursesAPI.Models;

namespace UniversityCoursesAPI.Services;

/// <summary>Хранилище курсов в памяти (потокобезопасное).</summary>
public class CourseService
{
    private readonly List<Course> _courses = new()
    {
        new Course { Id = 1, Title = "Разработка веб-сервисов", Description = "ASP.NET Core Web API, REST, аутентификация и авторизация", Teacher = "Герцен Е.А.", Duration = 90 },
        new Course { Id = 2, Title = "Базы данных", Description = "Реляционная модель, SQL, проектирование БД", Teacher = "Ахметов Б.К.", Duration = 120 },
        new Course { Id = 3, Title = "Алгоритмы и структуры данных", Description = "Сортировки, деревья, графы, оценка сложности", Teacher = "Серикова А.Н.", Duration = 135 },
        new Course { Id = 4, Title = "Объектно-ориентированное программирование", Description = "Классы, наследование, полиморфизм, SOLID", Teacher = "Нурланов Д.Т.", Duration = 105 },
        new Course { Id = 5, Title = "Основы информационной безопасности", Description = "Криптография, угрозы, защита приложений", Teacher = "Омарова Г.С.", Duration = 60 }
    };

    private int _nextId = 6;
    private readonly object _lock = new();

    public List<Course> GetAll()
    {
        lock (_lock) return _courses.ToList();
    }

    public Course? GetById(int id)
    {
        lock (_lock) return _courses.FirstOrDefault(c => c.Id == id);
    }

    public Course Add(Course course)
    {
        lock (_lock)
        {
            course.Id = _nextId++;
            _courses.Add(course);
            return course;
        }
    }

    public Course? Update(int id, Course updated)
    {
        lock (_lock)
        {
            var existing = _courses.FirstOrDefault(c => c.Id == id);
            if (existing is null) return null;

            existing.Title = updated.Title;
            existing.Description = updated.Description;
            existing.Teacher = updated.Teacher;
            existing.Duration = updated.Duration;
            return existing;
        }
    }

    public bool Delete(int id)
    {
        lock (_lock)
        {
            var existing = _courses.FirstOrDefault(c => c.Id == id);
            return existing is not null && _courses.Remove(existing);
        }
    }
}
