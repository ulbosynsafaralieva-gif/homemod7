namespace UniversityCoursesAPI.Models;

/// <summary>Модель пользователя системы.</summary>
public class User
{
    public int Id { get; set; }
    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;   // только для учебного примера (в реальности хранится хэш)
    public string Email { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;       // Admin, Teacher, Student
}
