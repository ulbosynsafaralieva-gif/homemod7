namespace UniversityCoursesAPI.Models;

/// <summary>Константы ролей, чтобы не использовать "магические строки".</summary>
public static class Roles
{
    public const string Admin = "Admin";
    public const string Teacher = "Teacher";
    public const string Student = "Student";
}
