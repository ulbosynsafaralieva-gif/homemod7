namespace UniversityCoursesAPI.Models;

/// <summary>Модель учебного курса.</summary>
public class Course
{
    public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string Teacher { get; set; } = string.Empty;
    public int Duration { get; set; }                      // длительность в часах
}
